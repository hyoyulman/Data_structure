#ifndef CDLIST_H
#define CDLIST_H

#include <iostream>
#include <string>

using std::string;
using std::ostream;

typedef string Elem;





......







#endif