#include "CDList.h"

CDList::CDList() : cursor(nullptr) {}

.....